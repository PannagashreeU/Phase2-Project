import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkoutsuccess',
  templateUrl: './checkoutsuccess.component.html',
  styleUrls: ['./checkoutsuccess.component.css']
})
export class CheckoutsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
